<?php 
$conexao = mysqli_connect('localhost', 'root', '123', 'loja');