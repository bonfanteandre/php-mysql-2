<?php include("cabecalho.php") ?>
	
	<p>
		Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sit amet aliquet lectus, ut mollis dui. Donec egestas arcu quis purus condimentum rhoncus. Nunc sit amet libero lectus. Vestibulum dapibus tincidunt orci quis rutrum. Sed scelerisque sit amet mauris sit amet viverra. Aliquam laoreet odio ut eros elementum aliquet. Mauris interdum, lectus sit amet imperdiet dictum, nisl lorem faucibus sem, vel molestie risus risus vitae lacus. Duis condimentum, lacus ut scelerisque aliquet, arcu eros vestibulum enim, a ultrices purus augue eu orci. Suspendisse placerat, nulla sed ornare laoreet, mi nulla venenatis metus, vitae vehicula sapien mauris at dui. Aliquam ultrices dapibus erat, eu auctor urna faucibus a. Nullam sed diam vitae turpis tempus convallis. Aliquam erat volutpat. Praesent in dui consequat, elementum nisl a, bibendum neque.
	</p>

	<p>
		Quisque vel commodo nunc. Aliquam at ipsum nec erat vestibulum eleifend vitae nec leo. Phasellus eget eleifend ex, id condimentum urna. Pellentesque tempus lobortis turpis, sed semper ex sodales et. In nec molestie lacus, a lacinia ipsum. Proin egestas sodales nunc in eleifend. Curabitur hendrerit, nisi in condimentum accumsan, erat neque aliquet enim, sed tempus dui metus sed mi. Integer interdum tristique vehicula. Duis sit amet orci vehicula, interdum leo dapibus, auctor neque. Nullam molestie sed diam at dapibus. Cras sed orci a eros venenatis venenatis.
	</p>

<?php include("rodape.php") ?>